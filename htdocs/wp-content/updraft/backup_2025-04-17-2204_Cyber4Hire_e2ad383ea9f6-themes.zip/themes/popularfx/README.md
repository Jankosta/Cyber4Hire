popularfx
===

This is a starter theme called `popularfx`. PopularFX is a very light weight theme meant for making beautiful websites with Pagelayer. Try turning this theme into the next, most awesome, WordPress theme / website out there !

* Licensed under LGPLv2.1 :) Use it to make something cool !

Installation
---------------

### Requirements

`popularfx` requires the following dependencies:

- [Pagelayer](https://pagelayer.com/)
- [WordPress](https://wordpress.org/)

### Quick Start

Just install and activate