<?php if (is_active_sidebar('envo-royal-right-sidebar')) { ?>
    <aside id="sidebar" class="col-md-3">
        <?php dynamic_sidebar('envo-royal-right-sidebar'); ?>
    </aside>
<?php 
}
